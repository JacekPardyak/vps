"""alias for configure.py"""
import configure

configure.dispatch_subcommand("mp.py")
