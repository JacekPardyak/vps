pyglet.shapes
=============

.. automodule:: pyglet.shapes
    :members:
    :inherited-members:
