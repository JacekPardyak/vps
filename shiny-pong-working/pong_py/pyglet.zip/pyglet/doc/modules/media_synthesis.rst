pyglet.media.synthesis
======================

.. automodule:: pyglet.media.synthesis
  :members:
  :undoc-members:
