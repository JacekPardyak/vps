pyglet.graphics.allocation
==========================

.. automodule:: pyglet.graphics.allocation
  :members:
  :undoc-members:
