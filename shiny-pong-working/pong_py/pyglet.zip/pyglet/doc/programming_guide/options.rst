pyglet options
==============

.. automodule:: pyglet
   :members:
