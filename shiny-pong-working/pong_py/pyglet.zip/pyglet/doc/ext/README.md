
# Custom Theme

The `ext` directory contains the old sphinx theme that was replaced with
`sphinx-rtd-theme` in 2019. The custom theme is somewhat broken with newer
versions of sphinx.

We probably want to spend our valuable time improving pyglet than maintaining a custom theme, but be free to
revive this in the future!
